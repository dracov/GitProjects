/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gemalto.split.masivos.beans;

import java.util.List;

/**
 *
 * @author aldmendo
 */
public class Cct {
    private String cctnombre;
    private List<CsvFileBean> records;

    public String getCctnombre() {
        return cctnombre;
    }

    public void setCctnombre(String cctnombre) {
        this.cctnombre = cctnombre;
    }

    public List<CsvFileBean> getRecords() {
        return records;
    }

    public void setRecords(List<CsvFileBean> records) {
        this.records = records;
    }
    
}
