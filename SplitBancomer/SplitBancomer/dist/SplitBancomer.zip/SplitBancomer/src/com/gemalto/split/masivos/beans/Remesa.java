/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gemalto.split.masivos.beans;

import java.util.List;

/**
 *
 * @author aldmendo
 */
public class Remesa {
    private String remesa;
    private List<Estado> listEstados;

    
    public Remesa(String remesa, List<Estado> listEstados){
        this.remesa=remesa;
        this.listEstados=listEstados;
    
    }
    
    public String getRemesa() {
        return remesa;
    }

    public void setRemesa(String remesa) {
        this.remesa = remesa;
    }

    public List<Estado> getListEstados() {
        return listEstados;
    }

    public void setListEstados(List<Estado> listEstados) {
        this.listEstados = listEstados;
    }
    
    
    
    
    
}
