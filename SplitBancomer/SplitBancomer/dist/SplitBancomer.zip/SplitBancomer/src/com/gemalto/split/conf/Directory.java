/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gemalto.split.conf;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 *
 * @author aldmendo
 */
public class Directory {
   
    @XStreamAlias("inputFolder")
    private String inputFolder;
    
    @XStreamAlias("outputFolder")
    private String outputFolder;
    
    @XStreamAlias("tempFolder")
    private String tempFolder;
    
    @XStreamAlias("archiveFolder")
    private String archiveFolder;
    
    @XStreamAlias("errorFolder")
    private String errorFolder;

    public String getArchiveFolder() {
        return archiveFolder;
    }

    public void setArchiveFolder(String archiveFolder) {
        this.archiveFolder = archiveFolder;
    }

    public String getErrorFolder() {
        return errorFolder;
    }

    public void setErrorFolder(String errorFolder) {
        this.errorFolder = errorFolder;
    }

    public String getInputFolder() {
        return inputFolder;
    }

    public void setInputFolder(String inputFolder) {
        this.inputFolder = inputFolder;
    }

    public String getOutputFolder() {
        return outputFolder;
    }

    public void setOutputFolder(String outputFolder) {
        this.outputFolder = outputFolder;
    }

    public String getTempFolder() {
        return tempFolder;
    }

    public void setTempFolder(String tempFolder) {
        this.tempFolder = tempFolder;
    }

 
    

    @Override
    public String toString() {
        return "Directory{" + "inputFolder=" + inputFolder + ", outputFolder=" + outputFolder + ", tempFoler=" + tempFolder + ", archiveFolder=" + archiveFolder + ", errorFolder=" + errorFolder + '}';
    }
    
    
    
    
    
}
