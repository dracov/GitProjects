/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gemalto.split.masivos.beans;

import com.googlecode.jcsv.annotations.MapToColumn;

/**
 *
 * @author aldmendo
 */
public class CsvFileBean {
    
@MapToColumn(column = 0)
private String consecutivo;
    
@MapToColumn(column = 1)
private String estado;
    
@MapToColumn(column = 2)
private String localidad;
    
@MapToColumn(column = 3)
private String cct;
    
@MapToColumn(column = 4)
private String noTarjeta;
   
@MapToColumn(column = 5)
private String remesa;

    public String getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(String consecutivo) {
        this.consecutivo = consecutivo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCct() {
        return cct;
    }

    public void setCct(String cct) {
        this.cct = cct;
    }

    public String getNoTarjeta() {
        return noTarjeta;
    }

    public void setNoTarjeta(String noTarjeta) {
        this.noTarjeta = noTarjeta;
    }

    public String getRemesa() {
        return remesa;
    }

    public void setRemesa(String remesa) {
        this.remesa = remesa;
    }

    @Override
    public String toString() {
        return "CsvFileBean{" + "consecutivo=" + consecutivo + ", estado=" + estado + ", localidad=" + localidad + ", cct=" + cct + ", noTarjeta=" + noTarjeta + ", remesa=" + remesa + '}';
    }
    
    
           
    
    
}
